import os
import cv2
import torch
import numpy as np
import albumentations as A
from torch.utils.data import Dataset
from transformers import SegformerImageProcessor, SegformerForSemanticSegmentation, TrainingArguments, Trainer

# ── 1. Configuration ──────────────────────────────────────────
IMAGE_DIR = "./dataset/input"
MASK_DIR = "./dataset/output"
MODEL_NAME = "nvidia/mit-b0"
OUTPUT_DIR = "./my-custom-lane-model"

# ── 2. AGGRESSIVE ON-THE-FLY AUGMENTATION ─────────────────────
train_transform = A.Compose([
    # --- NEW: Explicitly resize to model's native resolution ---
    A.Resize(height=512, width=512),
    
    # Geometric
    A.HorizontalFlip(p=0.5), 
    A.Affine(scale=(0.9, 1.1), translate_percent=(-0.1, 0.1), rotate=(-15, 15), p=0.5), 
    
    # Lighting & Exposure Modulators
    A.RandomBrightnessContrast(
        brightness_limit=(-0.5, 0.4), 
        contrast_limit=(-0.4, 0.5),   
        p=0.8                         
    ),
    A.RandomGamma(gamma_limit=(60, 150), p=0.4),
    
    # Blur Modulators
    A.MotionBlur(blur_limit=7, p=0.5),
    A.GaussianBlur(blur_limit=(3, 7), p=0.3),
    
    # Noise
    A.GaussNoise(var_limit=(10.0, 50.0), p=0.3),
])

processor = SegformerImageProcessor.from_pretrained(MODEL_NAME, token=MY_TOKEN)

# ── 3. Custom Dataset Loader ──────────────────────────────────
class LaneDataset(Dataset):
    def __init__(self, image_dir, mask_dir, processor, transform=None):
        self.image_dir = image_dir
        self.mask_dir = mask_dir
        self.processor = processor
        self.transform = transform
        self.images = sorted([f for f in os.listdir(image_dir) if f.endswith('.png')])

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img_name = self.images[idx]
        
        base_name = img_name.replace(".png", "")
        mask_name = f"{base_name}_mask.png"
        
        img_path = os.path.join(self.image_dir, img_name)
        mask_path = os.path.join(self.mask_dir, mask_name)

        image = cv2.imread(img_path)
        if image is None:
            raise ValueError(f"Could not load image: {img_path}")
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
        if mask is None:
            raise ValueError(f"Could not load mask: {mask_path}")
        
        mask = (mask > 128).astype(np.uint8)

        if self.transform is not None:
            augmented = self.transform(image=image, mask=mask)
            image = augmented['image']
            mask = augmented['mask']

        inputs = self.processor(images=image, segmentation_maps=mask, return_tensors="pt")
        inputs = {k: v.squeeze(0) for k, v in inputs.items()}
        return inputs

# ── 4. Initialize Dataset and Model ───────────────────────────
train_dataset = LaneDataset(IMAGE_DIR, MASK_DIR, processor, transform=train_transform)

model = SegformerForSemanticSegmentation.from_pretrained(
    MODEL_NAME,
    token=MY_TOKEN,
    num_labels=2,
    id2label={0: "background", 1: "lane"},
    label2id={"background": 0, "lane": 1},
    ignore_mismatched_sizes=True 
)

# ── 5. Define Training Rules ──────────────────────────────────
training_args = TrainingArguments(
    output_dir=OUTPUT_DIR,
    learning_rate=0.00006,
    num_train_epochs=40,             
    per_device_train_batch_size=4,   
    save_steps=50,
    save_total_limit=2,              
    remove_unused_columns=False,     
    logging_steps=10,
    # Removed the overwrite_output_dir line here
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
)

# ── 6. Start Training ────────────────────────────────────────
print(f"Found {len(train_dataset)} images. Starting training...")
trainer.train()

trainer.save_model(OUTPUT_DIR)
processor.save_pretrained(OUTPUT_DIR)
print(f"Training complete! Robust model saved to {OUTPUT_DIR}")
