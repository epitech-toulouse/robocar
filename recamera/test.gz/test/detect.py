import torch
import numpy as np
import cv2
from transformers import SegformerImageProcessor, SegformerForSemanticSegmentation
from PIL import Image
import sys
import os

# ── 1. Model setup ────────────────────────────────────────────
model_id = "./my-custom-lane-model"
processor = SegformerImageProcessor.from_pretrained(model_id)
model = SegformerForSemanticSegmentation.from_pretrained(model_id)
model.eval()

THRESHOLD = 0.35  
LAST_KNOWN_LANE_WIDTH = 280 
BARRICADE_THRESHOLD = 0.40   

def get_lane_mask(raw_img: np.ndarray) -> np.ndarray:
    h, w = raw_img.shape[:2]
    lab = cv2.cvtColor(raw_img, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8)).apply(l)
    enhanced = cv2.cvtColor(cv2.merge((l, a, b)), cv2.COLOR_LAB2BGR)
    
    inputs = processor(images=Image.fromarray(cv2.cvtColor(enhanced, cv2.COLOR_BGR2RGB)), return_tensors="pt")
    with torch.no_grad():
        outputs = model(**inputs)

    logits = torch.nn.functional.interpolate(outputs.logits, size=(h, w), mode="bilinear", align_corners=False)
    probs = torch.softmax(logits, dim=1)
    lane_mask = (probs[0, 1].numpy() > THRESHOLD).astype(np.uint8) * 255
    
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    lane_mask = cv2.morphologyEx(lane_mask, cv2.MORPH_CLOSE, kernel)
    return lane_mask

def is_valid_lane_row(row_pixels, min_gap=140, max_gap=470):
    """Helper to check if a single row looks like a lane."""
    white_indices = np.where(row_pixels > 0)[0]
    if len(white_indices) < 5:
        return False, None, None
    
    p_lx, p_rx = white_indices[0], white_indices[-1]
    gap = p_rx - p_lx
    
    # Check 1: Is the width sane?
    if not (min_gap < gap < max_gap):
        return False, None, None
    
    # Check 2: Is the middle empty? (Literal pixel check)
    mid_p = (p_lx + p_rx) // 2
    if row_pixels[mid_p] > 0:
        return False, None, None
        
    return True, p_lx, p_rx

def process(image_path: str):
    global LAST_KNOWN_LANE_WIDTH
    raw_img = cv2.imread(image_path)
    if raw_img is None: return

    raw_img = cv2.resize(raw_img, (512, 512))
    h, w = raw_img.shape[:2]
    mid_x = w // 2
    lane_mask = get_lane_mask(raw_img)
    
    # ── A. BARRICADE CHECK ─────────────────────────────────────
    wall_y = int(h * 0.70)
    is_barricaded = np.count_nonzero(lane_mask[wall_y, :]) > (w * BARRICADE_THRESHOLD)

    # ── B. FULL-IMAGE VERTICAL SWEEP WITH TUNNEL CONFIRMATION ──
    lx, rx, found_y = None, None, None
    
    # Sweep from bottom up
    for y in range(h - 15, 100, -1):
        valid, cur_lx, cur_rx = is_valid_lane_row(lane_mask[y, :])
        
        if valid:
            # CANDIDATE FOUND! Now validate the 'Tunnel' (check 10 rows above)
            confirm_count = 0
            check_range = 10
            for check_y in range(y - 1, y - check_range - 1, -1):
                v, _, _ = is_valid_lane_row(lane_mask[check_y, :])
                if v: confirm_count += 1
            
            # If 80% of rows above confirm the lane, we lock it in
            if confirm_count >= 8:
                lx, rx, found_y = cur_lx, cur_rx, y
                LAST_KNOWN_LANE_WIDTH = rx - lx
                break
            else:
                # False positive (likely a horizontal edge), keep sweeping
                continue

    # ── C. DECISION LOGIC ──────────────────────────────────────
    target_x = mid_x
    status = "SEARCHING"
    status_color = (150, 150, 150)
    display_y = found_y if found_y else int(h * 0.80)

    if is_barricaded:
        status = "BARRICADE"
        status_color = (0, 0, 255)
        l_mass = np.count_nonzero(lane_mask[int(h*0.1):int(h*0.5), :mid_x])
        r_mass = np.count_nonzero(lane_mask[int(h*0.1):int(h*0.5), mid_x:])
        # Force 100% turn even on barricade escape
        target_x = 5 if l_mass > r_mass else w - 5
    
    elif lx is not None and rx is not None:
        target_x = (lx + rx) // 2
        status = "CENTERED (Tunnel)"
        status_color = (0, 255, 0)
        
    else:
        # ── SHARP TURN OVERRIDE ──
        status = "SHARP TURN"
        status_color = (0, 165, 255)
        pixels = np.where(lane_mask[int(h*0.4):, :] > 0)
        
        if len(pixels[1]) > 0:
            avg_x = np.mean(pixels[1])
            # If line is on the left, slam steer to the right (100%)
            if avg_x < mid_x:
                target_x = w - 5 
                status = "FULL RIGHT TURN (100%)"
            else:
                # If line is on the right, slam steer to the left (-100%)
                target_x = 5
                status = "FULL LEFT TURN (100%)"
        else:
            status = "LOST: SEARCHING"
            target_x = mid_x

    # ── D. CALC OFFSET ─────────────────────────────────────────
    # The math here will now naturally output ~100% because target_x is at the screen edge
    dev_pct = np.clip(((target_x - mid_x) / (mid_x)) * 100, -100, 100)

    # ── E. UI COMPOSE ──────────────────────────────────────────
    out = raw_img.copy()
    if lx is not None and rx is not None:
        cv2.line(out, (lx, found_y), (rx, found_y), (0, 255, 255), 2)
        # Visualizing the validation 'tunnel' area
        cv2.rectangle(out, (lx-10, found_y - 10), (rx+10, found_y), (0, 255, 255), 1)

    cv2.circle(out, (int(target_x), display_y), 12, (255, 0, 0), -1)
    cv2.drawMarker(out, (mid_x, display_y), (255, 255, 255), cv2.MARKER_CROSS, 15, 2)

    cv2.putText(out, f"STATUS: {status}", (20, 45), 2, 0.5, status_color, 2)
    cv2.putText(out, f"DEV: {dev_pct:+.1f}%", (20, 80), 2, 0.5, (255, 255, 255), 1)
    
    cv2.imshow("Tunnel-Validation Processor", out)
    cv2.imshow("Mask Debug", lane_mask)
    cv2.waitKey(0)

if __name__ == "__main__":
    img_path = sys.argv[1] if len(sys.argv) > 1 else "image.png"
    process(img_path)
